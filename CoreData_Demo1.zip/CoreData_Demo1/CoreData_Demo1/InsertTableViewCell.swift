//
//  InsertTableViewCell.swift
//  CoreData_Demo1
//
//  Created by Shubham Shinde on 03/02/21.
//

import UIKit

class InsertTableViewCell: UITableViewCell {

    var student : Student! {
        didSet {
            nameLable.text = student.name
            addressLable.text = student.address
            cityLable.text = student.city
            mobileLable.text = student.mobile
        }
    }
    
    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var addressLable: UILabel!
    @IBOutlet weak var cityLable: UILabel!
    @IBOutlet weak var mobileLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
