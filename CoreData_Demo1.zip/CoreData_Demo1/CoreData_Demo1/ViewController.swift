//
//  ViewController.swift
//  CoreData_Demo1
//
//  Created by Shubham Shinde on 02/02/21.
//

import UIKit

class ViewController: UIViewController, DataPass {
    
    

    
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var addressTxt: UITextField!
    @IBOutlet weak var cityTxt: UITextField!
    @IBOutlet weak var mobileTxt: UITextField!
    var i = Int()
    var isUpdate = Bool()
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    @IBAction func saveButton(_ sender: Any) {
        
        let dict = ["name":nameTxt.text,"address":addressTxt.text,"city":cityTxt.text,"mobile":mobileTxt.text]
        if isUpdate {
            DataBaseHelper.shareInstence.editData(object: dict as! [String:String], i: i)
        } else {
            DataBaseHelper.shareInstence.save(object: dict as! [String: String])
        }
    }
    
    @IBAction func showButton(_ sender: Any) {
        let next = storyboard?.instantiateViewController(withIdentifier: "InsertViewController") as! InsertViewController
        next.deleget = self
        navigationController?.pushViewController(next, animated: true)
    }
    
    func data(object: [String : String], index: Int, isEdit: Bool) {
        nameTxt.text = object["name"]
        addressTxt.text = object["address"]
        cityTxt.text = object["city"]
        mobileTxt.text = object["mobile"]
        i = index
        isUpdate = isEdit
    }
}

