//
//  Student+CoreDataClass.swift
//  CoreData_Demo1
//
//  Created by Shubham Shinde on 03/02/21.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
